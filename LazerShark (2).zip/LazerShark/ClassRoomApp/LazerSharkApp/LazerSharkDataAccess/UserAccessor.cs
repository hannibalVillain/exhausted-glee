﻿using LazerSharkDataObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LazerSharkDataAccess
{
    public class UserAccessor
    {
        public static int VerifyUsernameAndPassword(string username, string passwordHash)
        {
            var result = 0;

            // Connecting to LazerSharkDB
            var conn = DBConnection.GetConnection();
            var cmdText = @"sp_authenticate_user";

            // Creating commmand object
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            // Adding Parameters
            cmd.Parameters.Add("@Username", SqlDbType.VarChar, 20);
            cmd.Parameters.Add("@PasswordHash", SqlDbType.VarChar, 100);

            // Setting parameter values
            cmd.Parameters["@Username"].Value = username;
            cmd.Parameters["@PasswordHash"].Value = passwordHash;

            try
            {
                // Opening connection to LazerSharkDB
                conn.Open();

                result = (int)cmd.ExecuteScalar();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                // Closing the connection
                conn.Close();
            }
            return result;
        }

        public static Customer RetrieveCustomerByUsername(string username)
        {
            Customer _customer = null;

            var conn = DBConnection.GetConnection();
            var cmdText = @"sp_retrieve_customer_by_username";
            var cmd = new SqlCommand(cmdText, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Username", SqlDbType.VarChar, 20);
            cmd.Parameters["@Username"].Value = username;

            try
            {
                conn.Open();
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();
                    _customer = new Customer()
                    { // CustomerID, FirstName, LastName, PhoneNumber, Address, Email, Username
                        CustomerID = reader.GetInt32(0),
                        FirstName = reader.GetString(1),
                        LastName = reader.GetString(2),
                        PhoneNumber = reader.GetString(3),
                        Address = reader.GetString(4),
                        Email =reader.GetString(5),
                        Username = reader.GetString(6)
                    };
                    reader.Close();
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return _customer;

        }

    }
}
