﻿using LazerSharkDataAccess;
using LazerSharkDataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LazerSharkLogicLayer
{
    public class MovieManager
    {
        public List<Movie> _movies = null;

        public List<Movie> RetrieveMoviesForRent()
        {
            try
            {
                _movies = MovieAccessor.RetrieveAvailableMovies();
            }
            catch (Exception)
            {

                
            }
            return _movies;           
        }
    }
}
