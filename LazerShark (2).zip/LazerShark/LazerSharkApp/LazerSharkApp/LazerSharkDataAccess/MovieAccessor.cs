﻿using LazerSharkDataObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LazerSharkDataAccess
{
    public class MovieAccessor
    {
        public static List<Movie> RetrieveAvailableMovies()//int quantityAvailable
        {
            var movies = new List<Movie>();

            var conn = DBConnection.GetConnection();
            var cmdText = @"sp_retrieve_available_movies";
            var cmd = new SqlCommand(cmdText, conn);

            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@QuantityAvailable", SqlDbType.Int);
            //cmd.Parameters["@QuantityAvailable"].Value = quantityAvailable;

            try
            {
                conn.Open();
                var reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        movies.Add(new Movie()
                        {
                            MovieID = reader.GetInt32(0),
                            GenreID = reader.GetString(1),
                            Description = reader.GetString(2),
                            Rating = reader.GetString(3),
                            Medium = reader.GetString(4),
                            QuantityAvailable = reader.GetInt32(5),
                            Quantity = reader.GetInt32(6),
                            RentalPrice = reader.GetDouble(7)
                        });
                    }
                    reader.Close();
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }

            return movies;
        }
    }
}
