﻿using LazerSharkDataObjects;
using LazerSharkLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfPresentationLayer
{
    /// <summary>
    /// Interaction logic for AdminOrderUI.xaml
    /// </summary>
    public partial class AdminOrderUI : Window
    {
        List<Movie> movies = new List<Movie>();
        MovieManager movMgr = new MovieManager();
        List<Game> games = new List<Game>();
        GameManager gamMgr = new GameManager();
        int supplierId;

        public AdminOrderUI()
        {
            InitializeComponent();
            
        }

        public void GetSupplierMovies()
        {
            try
            {
                movies = movMgr.GetSupplierMovieStock(supplierId);
                foreach (var movie in movies)
                {
                    lstMovies.Items.Add(movie.Title);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Something went wrong when retrieving movies from supplier");
            }
            

        }

        public void GetSupplierGames()
        {
            try
            {
                games = gamMgr.RetrieveSupplierGamesStock(supplierId);
                foreach (var game in games)
                {
                    lstGames.Items.Add(game.Title);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Something went wrong when retrieving games from supplier");
            }
            

        }

        private void radBJ_Checked(object sender, RoutedEventArgs e)
        {
            supplierId = 100000;
            lstMovies.Items.Clear();
            lstGames.Items.Clear();
            GetSupplierMovies();
            GetSupplierGames();

        }

        private void radWholeSale_Checked(object sender, RoutedEventArgs e)
        {
            supplierId = 100001;
            lstMovies.Items.Clear();
            lstGames.Items.Clear();
            GetSupplierMovies();
            GetSupplierGames();
        }

        private void radDa_Checked(object sender, RoutedEventArgs e)
        {
            supplierId = 100002;
            lstMovies.Items.Clear();
            lstGames.Items.Clear();
            GetSupplierMovies();
            GetSupplierGames();
        }
    }
}
