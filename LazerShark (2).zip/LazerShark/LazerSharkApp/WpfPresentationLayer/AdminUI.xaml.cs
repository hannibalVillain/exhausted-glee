﻿using LazerSharkDataObjects;
using LazerSharkLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfPresentationLayer
{
    /// <summary>
    /// Interaction logic for AdminUI.xaml
    /// </summary>
    public partial class AdminUI : Window
    {
        List<Movie> movies = new List<Movie>();
        List<Game> games = new List<Game>();
        MovieManager movMgr = new MovieManager();
        GameManager gamMgr = new GameManager();
        int kioskId = 100001;
        int adminId = 100001;

        public AdminUI()
        {

            InitializeComponent();
            movies = movMgr.RetrieveMoviesByKioskIdAndAdminId(kioskId, adminId);
            games = gamMgr.RetrieveGamesInKiosk(kioskId, adminId);
            refreshMedia();
        }




        private void refreshMedia()
        {
            foreach (var movie in movies)
            {
                lstMovieList.Items.Add(movie.Title + " - In Stock:  " + movie.QuantityAvailable );
            }

            foreach (var game in games)
            {
                lstGameList.Items.Add(game.Title + " - In Stock:  " + game.QuantityAvailable);
            }
            
            
        }

        private void btnOrder_Click(object sender, RoutedEventArgs e)
        {
            AdminOrderUI orderUI = new AdminOrderUI();
            orderUI.ShowDialog();
            
        }

    }
}
