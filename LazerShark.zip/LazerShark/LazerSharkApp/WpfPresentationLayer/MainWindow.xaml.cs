﻿using LazerSharkDataObjects;
using LazerSharkLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfPresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private UserManager usrMgr = new UserManager();
        private MovieManager movMgr = new MovieManager();
        private GameManager gamMgr = new GameManager();
        private List<Movie> movies = new List<Movie>();
        private List<Game> games = new List<Game>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {            
        }

        private void RefreshGamesForRental()
        {

            LstMediaList.Items.Clear();

            foreach (var game in games)
            {
                LstMediaList.Items.Add(game.Title + " - In Stock:  " + game.QuantityAvailable);
            }
        }

        private void RefreshMoviesForRent()
        {
            
            LstMediaList.Items.Clear();

            foreach (var movie in movies)
            {
                LstMediaList.Items.Add(movie.Title + " - In Stock:  " + movie.QuantityAvailable);
            }
        }

        private void btnLogIn_Click(object sender, RoutedEventArgs e)
        {
            // Launches a login window
            var _login = new Login();
           

            if ((string)btnLogIn.Content == "Log Out")
            {
                MessageBox.Show("Logged out");
                btnLogIn.Content = "Log In";
            }
            else if((string)btnLogIn.Content == "Log In")
            {                
                _login.ShowDialog();
                btnLogIn.Content = "Log Out";
            }
        }

        private void mnuQuit_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Terminating Program...");
            this.Close();
        }

        private void mnuAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            var login = new AdminLogin();
            login.ShowDialog();
        }

        private void cmbMovies_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                movies = movMgr.RetrieveMoviesForRent();
            }
            catch (Exception)
            {

                MessageBox.Show("There was an error retrieving your movies");
            }
            RefreshMoviesForRent();
            hideGameFilters();
            showMovieFilters();
        }

        private void cmbVideoGames_Selected(object sender, RoutedEventArgs e)
        {
            try
            {
                games = gamMgr.RetrieveGamesForRental();
            }
            catch (Exception)
            {

                MessageBox.Show("There was an error retrieving games for rental");
            }

            RefreshGamesForRental();
            showGameFilters();
            hideMovieFilters();
        }

        private void cmbAction_Selected(object sender, RoutedEventArgs e)
        {

            string genreId = "Action";

            if(cmbCategory.SelectedIndex == 0)
            {
                try
                {
                    movies = movMgr.RetrieveMoviesByGenre(genreId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving your movies");
                }
                RefreshMoviesForRent();
            }
        }

        private void cmbDrama_Selected(object sender, RoutedEventArgs e)
        {
            string genreId = "Drama";

            if (cmbCategory.SelectedIndex == 0)
            {
                try
                {
                    movies = movMgr.RetrieveMoviesByGenre(genreId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving your movies");
                }
                RefreshMoviesForRent();
            }
        }

        private void cmbComedy_Selected(object sender, RoutedEventArgs e)
        {
            string genreId = "Comedy";

            if (cmbCategory.SelectedIndex == 0)
            {
                try
                {
                    movies = movMgr.RetrieveMoviesByGenre(genreId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving your movies");
                }
                RefreshMoviesForRent();
            }
        }

        private void cmbDvd_Selected(object sender, RoutedEventArgs e)
        {
            string mediumId = "DVD";

            if(cmbCategory.SelectedIndex == 0)
            {
                try
                {
                    movies = movMgr.RetrieveMoviesByMedium(mediumId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving your movies");
                }
                RefreshMoviesForRent();
            }
        }

        private void cmbBluRay_Selected(object sender, RoutedEventArgs e)
        {
            string mediumId = "Blu-Ray";

            if (cmbCategory.SelectedIndex == 0)
            {
                try
                {
                    movies = movMgr.RetrieveMoviesByMedium(mediumId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving your movies");
                }
                RefreshMoviesForRent();
            }
        }

        private void hideGameFilters()
        {
            cmbRpg.Visibility = Visibility.Collapsed;
            cmbShooter.Visibility = Visibility.Collapsed;
            cmbSimulation.Visibility = Visibility.Collapsed;
            cmbPc.Visibility = Visibility.Collapsed;
            cmbPs4.Visibility = Visibility.Collapsed;
            cmbXbox.Visibility = Visibility.Collapsed;          
        }

        private void showGameFilters()
        {
            cmbRpg.Visibility = Visibility.Visible;
            cmbShooter.Visibility = Visibility.Visible;
            cmbSimulation.Visibility = Visibility.Visible;
            cmbPc.Visibility = Visibility.Visible;
            cmbPs4.Visibility = Visibility.Visible;
            cmbXbox.Visibility = Visibility.Visible;
        }

        private void hideMovieFilters()
        {
            cmbBluRay.Visibility = Visibility.Collapsed;
            cmbDvd.Visibility = Visibility.Collapsed;
            cmbComedy.Visibility = Visibility.Collapsed;
            cmbDrama.Visibility = Visibility.Collapsed;
        }

        private void showMovieFilters()
        {
            cmbBluRay.Visibility = Visibility.Visible;
            cmbDvd.Visibility = Visibility.Visible;
            cmbComedy.Visibility = Visibility.Visible;
            cmbDrama.Visibility = Visibility.Visible;
        }

        private void cmbShooter_Selected(object sender, RoutedEventArgs e)
        {
            string genreId = "Shooter";

            if (cmbCategory.SelectedIndex == 1)
            {
                try
                {
                    games = gamMgr.RetrieveGamesByGenreID(genreId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving games...");
                }
                RefreshGamesForRental();
            }
        }

        private void cmbSimulation_Selected(object sender, RoutedEventArgs e)
        {
            string genreId = "Simulation";

            if (cmbCategory.SelectedIndex == 1)
            {
                try
                {
                    games = gamMgr.RetrieveGamesByGenreID(genreId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving games...");
                }
                RefreshGamesForRental();
            }
        }

        private void cmbRpg_Selected(object sender, RoutedEventArgs e)
        {
            string genreId = "RPG";

            if (cmbCategory.SelectedIndex == 1)
            {
                try
                {
                    games = gamMgr.RetrieveGamesByGenreID(genreId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving games...");
                }
                RefreshGamesForRental();
            }
        }

        private void cmbXbox_Selected(object sender, RoutedEventArgs e)
        {
            string mediumId = "XBONE";

            if (cmbCategory.SelectedIndex == 1)
            {
                try
                {
                    games = gamMgr.RetrieveGamesByMediumId(mediumId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving games...");
                }
                RefreshGamesForRental();
            }
        }

        private void cmbPs4_Selected(object sender, RoutedEventArgs e)
        {
            string mediumId = "PS4";

            if (cmbCategory.SelectedIndex == 1)
            {
                try
                {
                    games = gamMgr.RetrieveGamesByMediumId(mediumId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving games...");
                }
                RefreshGamesForRental();
            }
        }

        private void cmbPc_Selected(object sender, RoutedEventArgs e)
        {
            string mediumId = "PC";

            if (cmbCategory.SelectedIndex == 1)
            {
                try
                {
                    games = gamMgr.RetrieveGamesByMediumId(mediumId);
                }
                catch (Exception)
                {

                    MessageBox.Show("There was an error retrieving games...");
                }
                RefreshGamesForRental();
            }
        }
    }
}
