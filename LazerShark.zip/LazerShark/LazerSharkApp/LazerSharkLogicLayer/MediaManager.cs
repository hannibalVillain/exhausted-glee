﻿using LazerSharkDataObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LazerSharkLogicLayer
{
    public class MediaManager
    {
        public List<Game> games = new List<Game>();
        public List<Movie> movies = new List<Movie>();
        decimal moviePrices;
        decimal gamePrices;


        public decimal CalculateMoviesTotal(decimal moviePrices)
        {
            decimal total = 0;
            this.moviePrices = moviePrices;
            total = moviePrices;

            return total;
        }

        public decimal CalculateGamesTotal(decimal gamePrices)
        {
            decimal total = 0;
            this.gamePrices = gamePrices;
            total = gamePrices;

            return total;
        }

        public decimal sumPrices()
        {
            decimal total = 0;
            total = moviePrices + gamePrices;
            return total;

        }
    }
}
