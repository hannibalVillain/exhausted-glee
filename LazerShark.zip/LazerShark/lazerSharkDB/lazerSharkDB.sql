IF EXISTS (SELECT 1 FROM master.dbo.sysdatabases WHERE name = 'lazerSharkDB')
BEGIN
	DROP DATABASE lazerSharkDB
	print '' print '*** dropping database lazerSharkDB ***'
END
GO

CREATE DATABASE lazerSharkDB
GO

print '' print '*** using database lazerSharkDB ***' 
GO
USE [lazerSharkDB]
GO

print '' print '*** Creating Movies Table ***'
GO
/* ***Object: Table[dbo].[Movies]*** */

CREATE TABLE [dbo].[Movies](
	[MovieID]			[int]IDENTITY(100000,1)	NOT NULL,
	[Title]				[varchar](250)			NOT NULL,
	[GenreID]			[varchar](50)			NOT NULL,
	[Description]		[varchar](500)			NOT NULL,
	[Rating]			[varchar](15)			NOT NULL,
	[Medium]			[varchar](20)			NOT NULL,
	[QuantityAvailable]	[int]					NOT NULL,
	[Quantity]			[int]					NOT NULL,
	[RentalPrice]		[decimal](7,2)			NOT NULL,

	
	CONSTRAINT [pk_MovieID] PRIMARY KEY ([MovieID] ASC)
)
GO

print '' print '*** Inserting Movies Sample Records ***'
GO
INSERT INTO [dbo].[Movies]
		([Title], [GenreID], [Description], [Rating], [Medium], [QuantityAvailable], [Quantity], [RentalPrice])
	VALUES
		('Face Kicker', 'Action', 'Jack Thompson kicks some dude"s face in', 'R', 'Blu-Ray', 3, 5, 2.99),
		('Apples 2 Oranges', 'Drama', 'No one can compare this movie to any other movie', 'PG','DVD', 1, 1, 1.99),
		('Face Kicker 2', 'Action', 'Jack is back, and he is pissed! Someone is about to get their face kicked off', 'R', 'Blu-Ray / DVD', 2, 5, 4.99)
GO


print '' print '*** Creating Games Table ***'
GO
/* ***Object: Table[dbo].[Games]*** */

CREATE TABLE [dbo].[Games](
	[GameID] 			[int]IDENTITY(100000,1)	NOT NULL,
	[Title]				[varchar](250)			NOT NULL,
	[GenreID]			[varchar](50)			NOT NULL,
	[Description]		[varchar](500)			NOT NULL,
	[Rating]			[varchar](15)			NOT NULL,
	[Medium]			[varchar](20)			NOT NULL,
	[QuantityAvailable]	[int]					NOT NULL,
	[Quantity]			[int]					NOT NULL,
	[RentalPrice]		[decimal](7,2)			NOT NULL,
	
	CONSTRAINT [pk_GameID] PRIMARY KEY ([GameID] ASC)
)
GO

print '' print '*** Inserting Games Sample Records ***'
GO
INSERT INTO [dbo].[Games]
	([Title], [GenreID], [Description], [Rating], [Medium], [QuantityAvailable], [Quantity], [RentalPrice])
	VALUES
		('Clown Simulator', 'Simulation', 'Super boring clown simulation game', 'E', 'PC', 1, 2, 5.99),
		('Shrapnel', 'First-Person Shooter', 'Shoot all of the bad guys', 'M', 'XBONE, PS4', 0, 2, 6.99),
		('Swords and Shields', 'RPG', 'Explore the deepest darkest dungeons, in an effort to save the princess', 'T', 'PS4', 2, 3, 5.99)
GO


print '' print '*** Creating Customer Table *** '
GO
/* ***Object: Table[dbo].[Customer]*** */

CREATE TABLE [dbo].[Customer](
	[CustomerID]	[int]IDENTITY(100000,1)	NOT NULL,
	[Username]		[varchar](20)			NOT NULL,
	[PasswordHash]	[varchar](100)			NOT NULL DEFAULT '9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e',
	[FirstName]		[varchar](250)			NOT NULL,
	[LastName]		[varchar](250)			NOT NULL,
	[PhoneNumber]	[varchar](9)			NOT NULL,
	[Address]		[varchar](500)			NOT NULL,
	[Email]			[varchar](200)			NOT NULL,
	
	CONSTRAINT [pk_CustomerID] PRIMARY KEY ([CustomerID] ASC),
	CONSTRAINT [ak_Username] UNIQUE ([Username] ASC)
)
GO

print '' print '*** Inserting Customer Sample Records ***'
GO
INSERT INTO [dbo].[Customer]
	([Username], [FirstName], [LastName], [PhoneNumber], [Address], [Email])
	VALUES
		('jimmyjohn', 'Jimmy', 'John', '123456789', '123 Abcd Street, Bowes, CA', 'jimmyjohn@food.com'),
		('muffman', 'Muffin', 'Mann', '234567891', '100 Drury Lane, Bowes, CA', 'muffinman@kirkwood.edu'),
		('duckman', 'Daffy', 'Duck', '345678912', '231 Looney Tunes Road, Bowes, CA', 'daffyduck@looneytunes.com')
GO

	
print '' print' **** Creating RentalRecord Table **** '
GO
/* ***Object: Table[dbo].[RentalRecord]*** */

CREATE TABLE [dbo].[RentalRecord](
	[RentalRecordID]	[int]IDENTITY(100000, 1)	NOT NULL, 
	[Terms]				[varchar](250)				NOT NULL,
	[PaymentMethod]		[varchar](250)				NOT NULL,
	[Total]				[decimal](7,2)				NOT NULL,
	[CustomerID]		[int]						NOT NULL,
	[KioskID]			[int]						NOT NULL,
	[DateRented]		[date]						NOT NULL,
	[MovieID]			[int]						,
	[GameID]			[int]						,
	
	CONSTRAINT [pk_RentalRecordID] PRIMARY KEY ([RentalRecordID] ASC)
)
GO

print '' print '*** Inserting Sample RentalRecords *** ' 
GO
INSERT INTO [dbo].[RentalRecord]
	([Terms], [PaymentMethod], [Total], [CustomerID], [KioskID], [DateRented], [MovieID], [GameID])
	VALUES
		('5 Days', 'MasterCard', 3.99, 100000, 100000, '10/01/2016', 100000, NULL),
		('10 Days', 'Visa', 6.99, 100001, 100000, '11/01/2016', NULL, 100000), 
		('15 Days', 'American Express', 9.99, 100002, 100000, '11/01/2016', 100001, 100001)
GO


print '' print '**** Creating Administrator Table ****'
GO
/* ***Object: Table[dbo].[Administrator]*** */

CREATE TABLE [dbo].[Administrator] (
	[AdministratorID]	[int]IDENTITY(100000, 1)	NOT NULL,
	[FirstName]			[varchar](250)				NOT NULL,
	[LastName]			[varchar](250)				NOT NULL,
	[Username]			[varchar](200)				NOT NULL,
	[PasswordHash]		[varchar](200)				NOT NULL DEFAULT '9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e',
	
	CONSTRAINT [pk_AdministratorID] PRIMARY KEY ([AdministratorID]ASC)
)
GO

print '' print'**** Inserting Sample Administrator Records ****'
GO
INSERT INTO [dbo].[Administrator]
	([FirstName], [LastName], [Username])
VALUES
	('Bob', 'Builder', 'bobTheBuilder')
GO

print '' print '**** Creating Supplier Table **** '
GO
/* ***Object: Table[dbo].[Supplier]*** */

CREATE TABLE [dbo].[Supplier](
	[SupplierID]	[int]IDENTITY(100000, 1)	NOT NULL,
	[Name]			[varchar](250)				NOT NULL,
	[MovieID]		[int]						,
	[GameID]		[int]						,
	
	CONSTRAINT [pk_SupplierID] PRIMARY KEY ([SupplierID] ASC)
)
GO

print '' print'**** Inserting Supplier Sample Records ****'
GO
INSERT INTO [dbo].[Supplier]
	([Name], [MovieID], [GameID])
	VALUES
		('BJ Media Supply', '100000', NULL),
		('Wholesale Media', 100001, 100000),
		('Wholesale Media', 100002, 100001)
GO

print '' print '**** Creating Kiosk Table ****'
GO
/* ***Object: Table[dbo].[Kiosk]*** */

CREATE TABLE [dbo].[Kiosk](
	[KioskID] 			[int]IDENTITY(100000, 1)	NOT NULL,
	[AdministratorID]	[int]						NOT NULL,
	[GameID]			[int]						NOT NULL,
	[MovieID]			[int]						NOT NULL,
	
	CONSTRAINT	[pk_KioskID] PRIMARY KEY ([KioskID]ASC)
)
GO

print '' print'**** Inserting Sample Kiosk Records ****'
GO
INSERT INTO [dbo].[Kiosk]
	([AdministratorID], [GameID], [MovieID])
	VALUES
		(100000, 100000, 100000),
		(100000, 100001, 100001),
		(100000, 100002, 100002),
		(100000, 100003, 100003)
GO

print '' print '**** Creating Genre Table ****'
GO
/* ***Object: Table[dbo].[Genre]*** */

CREATE TABLE [dbo].[Genre] (
	[GenreID] [varchar](50)	NOT NULL,
	
	CONSTRAINT[pk_GenreID] PRIMARY KEY ([GenreID] ASC)
)
GO

print '' print '**** Inserting Sample Genre Records ****'
GO
INSERT INTO [dbo].[Genre]
	([GenreID])
	VALUES
		('Action'),
		('Drama'),
		('Comedy'),
		('Romance'),
		('First-Person Shooter'),
		('Simulation'),
		('RPG')
GO

print '' print'**** Creating SupplyRecord Table ****'
GO
/* ***Object: Table[dbo].[SupplyRecord]*** */

CREATE TABLE [dbo].[SupplyRecord](
	[SupplyRecordID]	[int]IDENTITY(100000, 1)	NOT NULL,
	[KioskID]			[int]						NOT NULL,
	[SupplierID]		[int]						NOT NULL,
	[RestockDate]		[date]						NOT NULL,
	[AdministratorID]	[int]						NOT NULL,
	
	CONSTRAINT	[pk_SupplyRecordID] PRIMARY KEY ([SupplyRecordID] ASC)
)
GO

print '' print '**** Inserting SupplyRecord Sample Records ****'
GO
INSERT INTO [dbo].[SupplyRecord]
	([KioskID], [SupplierID], [RestockDate], [AdministratorID])
	VALUES
		(100000, 100000, '11/01/2016', 100000),
		(100000, 100003, '11/01/2016', 100000),
		(100000, 100001, '11/01/2016', 100000)
GO



print '' print '**** Creating Movies GenreID Foreign Key ****'
GO
ALTER TABLE [dbo].[Movies] WITH NOCHECK
	ADD CONSTRAINT [fk_GenreID] FOREIGN KEY ([GenreID])
	REFERENCES [dbo].[Genre] ([GenreID])
	ON UPDATE CASCADE
GO

print '' print '**** Creating RentalRecord KioskID foreign key ****'
GO
ALTER TABLE [dbo].[RentalRecord] WITH NOCHECK
	ADD CONSTRAINT [fk_KioskID] FOREIGN KEY ([KioskID])
	REFERENCES [dbo].[Kiosk] ([KioskID])
	ON UPDATE CASCADE
GO

print '' print '**** Creating RentalRecord CustomerID foreign key ****'
GO
ALTER TABLE [dbo].[RentalRecord] WITH NOCHECK
	ADD CONSTRAINT [fk_CustomerID] FOREIGN KEY ([CustomerID])
	REFERENCES [dbo].[Customer] ([CustomerID])
	ON UPDATE CASCADE
GO

print '' print '**** Creating RentalRecord MovieID foreign key ****'
GO
ALTER TABLE [dbo].[RentalRecord] WITH NOCHECK
	ADD CONSTRAINT [fk_MovieID] FOREIGN KEY ([MovieID])
	REFERENCES [dbo].[Movies] ([MovieID])
	ON UPDATE CASCADE
GO

print '' print '**** Creating RentalRecord GameID foreign key ****'
GO
ALTER TABLE [dbo].[RentalRecord] WITH NOCHECK
	ADD CONSTRAINT [fk_GameID] FOREIGN KEY ([GameID])
	REFERENCES [dbo].[Games] ([GameID])
	ON UPDATE CASCADE
GO

print '' print '**** Creating SuplyRecord AdministratorID foreign key ****'
GO
ALTER TABLE [dbo].[SupplyRecord] WITH NOCHECK
	ADD CONSTRAINT [fk_AdministratorID] FOREIGN KEY ([AdministratorID])
	REFERENCES [dbo].[Administrator] ([AdministratorID])
	ON UPDATE CASCADE
GO

print '' print '**** Creating SuplyRecord SupplierID foreign key ****'
GO
ALTER TABLE [dbo].[SupplyRecord] WITH NOCHECK
	ADD CONSTRAINT [fk_SupplierID] FOREIGN KEY ([SupplierID])
	REFERENCES [dbo].[Supplier] ([SupplierID])
	ON UPDATE CASCADE
GO

print '' print '**** Creating sp_authenticate_user ****'
GO
CREATE PROCEDURE [dbo].[sp_authenticate_user]
	(
	@Username varchar(20),
	@PasswordHash varchar(100)
	)
AS
	BEGIN
		SELECT COUNT (CustomerID)
		FROM Customer
		WHERE Username = @Username
		AND PasswordHash = @PasswordHash
	END
GO

print '' print '**** Creating sp_retrieve_customer_by_username'
GO
CREATE PROCEDURE [dbo].[sp_retrieve_customer_by_username]
	(
	@Username varchar(20)
	)
AS
	BEGIN
		SELECT CustomerID, FirstName, LastName, PhoneNumber, Address, Email, Username
		FROM Customer
		WHERE Username = @Username
	END
GO
	
print '' print '**** Creating sp_update_passwordHash ****'
GO
CREATE PROCEDURE [dbo].[sp_update_passwordHash]
(
	@Username varchar(20),
	@OldPasswordHash varchar(100),
	@NewPasswordHash varchar(100)
)
AS
	BEGIN
		UPDATE Customer
			SET PasswordHash = @NewPasswordHash
			WHERE Username = @Username
			AND PasswordHash = @OldPasswordHash
		RETURN @@ROWCOUNT
	END
GO

print '' print '**** Creating sp_add_user ****'
GO
CREATE PROCEDURE [dbo].[sp_add_user]
(
	@Username varchar(20),
	@PasswordHash varchar(100),
	@FirstName varchar(250), 
	@LastName varchar(250), 
	@PhoneNumber varchar(9),
	@Address varchar(500),
	@Email varchar(200)
)
AS
	BEGIN
		INSERT INTO [dbo].[Customer]
		([Username], [PasswordHash], [FirstName], [LastName], [PhoneNumber], [Address], [Email])
		VALUES
			(@Username, @PasswordHash, @FirstName, @LastName, @PhoneNumber, @Address, @Email)
	END
GO
	